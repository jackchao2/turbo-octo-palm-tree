export default {
    pageTitle: '首页',
    infoList:[]
}