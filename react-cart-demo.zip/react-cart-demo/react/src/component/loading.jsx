import React,{Component} from 'react'

export default class loading extends Component{
    render(){
        return(
            <div className="pageLoading">
                <div className="loading">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        )
    }
}